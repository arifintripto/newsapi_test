<?php $__env->startSection('content'); ?>
    <div class="container">

        <div class="news">
            <div class="row mt-5">
                <?php if(isset($article->urlToImage)): ?>
                    <img src="<?php echo e($article->urlToImage); ?>" class="w-100" alt="news-photo">
                <?php else: ?>
                    <img src="<?php echo e(asset('img/placeholderimage.jpg')); ?>" class="w-100" alt="news-photo">
                <?php endif; ?>
            </div>
            <div class="row mb-5">
                <h1 class="display-3"><?php echo e($article->title); ?></h1>
                <p>
                    <span class="news-category"><?php echo e($category); ?></span>
                    <span class="news-author"><?php echo e($article->author); ?></span>
                    <span class="news-published-at"><?php echo e(substr($article->publishedAt, 0, 10)); ?></span>
                </p>
                <p class="mt-3"><?php echo e($article->content); ?></p>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\news\resources\views/news_details.blade.php ENDPATH**/ ?>