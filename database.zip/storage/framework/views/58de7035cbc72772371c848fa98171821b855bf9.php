<?php $__env->startSection('content'); ?>
    <div class="container">

        <?php $__currentLoopData = $articles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $article): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <div class="row g-0 mt-4 mb-4 bg-light position-relative article">
                <div class="col-md-4 mb-md-0 p-md-4">
                    <?php if(isset($article->urlToImage)): ?>
                        <img src="<?php echo e($article->urlToImage); ?>" class="w-100" alt="news-photo">
                    <?php else: ?>
                        <img src="<?php echo e(asset('img/placeholderimage.jpg')); ?>" class="w-100" alt="news-photo">
                    <?php endif; ?>
                </div>
                <div class="col-md-8 p-4 ps-md-0">
                    <h4 class="mt-0"><a href="<?php echo e(route('news_details', ['category' => $category, 'id' => $key])); ?>"
                                        class="stretched-link text-dark"><?php echo e($article->title); ?></a></h4>

                    
                    <p><?php echo $article->description; ?></p>
                    <p>
                        <span class="news-category"><?php echo e($category); ?></span>
                        <span class="news-published-at"><?php echo e(substr($article->publishedAt, 0, 10)); ?></span>
                    </p>
                </div>
            </div>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\news\resources\views/news.blade.php ENDPATH**/ ?>